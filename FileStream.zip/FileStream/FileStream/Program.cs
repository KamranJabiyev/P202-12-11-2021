﻿using FileStream.Models;
using Magnum.FileSystem;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Xml2CSharp;

namespace FileStream
{
    class Program
    {
        static void Main(string[] args)
        {
            //GetHttpContent();
            //GetHttpContentAsync();
            //Console.ReadLine();
            #region File,Directory
            //string[] files=Directory.GetFiles(@"C:/Users/Admin/Desktop/P202");
            //foreach (var file in files)
            //{
            //    Console.WriteLine(file);
            //}
            //string[] folders=Directory.GetDirectories(@"C:/Users/Admin/Desktop/P202");
            //foreach (var folder in folders)
            //{
            //    Console.WriteLine(folder);
            //}
            //Directory.CreateDirectory(@"C:/Users/Admin/Desktop/P202/test1");
            //Directory.CreateDirectory(@"C:/Users/Admin/Desktop/P202/test2");
            //File.Create(@"C:/Users/Admin/Desktop/P202/test1.txt");
            //File.Create(@"C:/Users/Admin/Desktop/P202/test2.txt");
            //if (!Directory.Exists(@"C:/Users/Admin/Desktop/P202"))
            //{
            //    Directory.CreateDirectory(@"C:/Users/Admin/Desktop/P202");
            //}
            //if (!File.Exists(@"C:/Users/Admin/Desktop/P202/test.txt"))
            //{
            //    File.Create(@"C:/Users/Admin/Desktop/P202/test.txt");
            //}

            //Directory.Delete(@"C:/Users/Admin/Desktop/P202/Inside",true);
            #endregion

            #region StreamReader,StreamWriter
            //string path = @"C:/Users/Admin/Desktop/P202/test.txt";
            //using (StreamWriter sw = new StreamWriter(path, true))
            //{
            //    sw.WriteLine("Ramal Abaszade3");
            //}
            //using (StreamReader sr = new StreamReader(path))
            //{
            //    Console.WriteLine(sr.ReadToEnd());
            //}
            //sr.Close();
            #endregion

            #region Json
            #region Serialize
            //Product p1 = new Product { Id = 1, Name = "Iphone XS", Price = 1300 };
            //Product p2 = new Product { Id = 2, Name = "Samsung", Price = 1000 };
            //OrderItem item1 = 
            //    new OrderItem() { Id = 1, Product = p1, Count = 2, TotalPrice = p1.Price * 2 };
            //OrderItem item2 = 
            //    new OrderItem() { Id = 2, Product = p2, Count = 2, TotalPrice = p2.Price * 2 };
            //List<OrderItem> items = new List<OrderItem>();
            //items.Add(item1);
            //items.Add(item2);
            //Order order = new Order { Id = 1, Items = items };

            //var jsonObject = JsonConvert.SerializeObject(order);
            //using (StreamWriter sw=new StreamWriter(@"D:\Aztu-P202\FileStream\FileStream\Files\json1.json"))
            //{
            //    sw.Write(jsonObject);
            //}
            #endregion
            #region Deserialize
            //string result;
            //using (StreamReader sr=new StreamReader(@"D:\Aztu-P202\FileStream\FileStream\Files\json1.json"))
            //{
            //    result=sr.ReadToEnd();
            //}
            //Order order = JsonConvert.DeserializeObject<Order>(result);
            //Console.WriteLine(order);
            #endregion
            #endregion

            #region Xml

            using (StreamReader sr = new StreamReader(@"D:\Aztu-P202\FileStream\FileStream\Files\XMLFile1.xml"))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ValCurs));
                ValCurs valCurs = (ValCurs)serializer.Deserialize(sr);
                foreach (var valType in valCurs.ValType)
                {
                    foreach (var valute in valType.Valute)
                    {
                        Console.WriteLine($"{valute.Name} - {valute.Value}");
                    }
                }
            }
                
            //Console.WriteLine(result);

            #endregion
        }

        #region Multitasking
        public async static Task GetHttpContentAsync()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var tasks = new List<Task<string>>();
            foreach (var item in GetUrls())
            {
                HttpClient client = new HttpClient();
                tasks.Add(client.GetStringAsync(item));
            }
            await Task.WhenAll(tasks);
            foreach (var result in tasks)
            {
                Console.WriteLine(result.Result.Length);
            }
            sw.Stop();
            Console.WriteLine($"multitasking: {sw.ElapsedMilliseconds}");
        }
        public static void GetHttpContent()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            foreach (var item in GetUrls())
            {
                HttpClient client = new HttpClient();
                string result = client.GetStringAsync(item).Result;
                Console.WriteLine(item+" -> "+result.Length);
            }
            sw.Stop();
            Console.WriteLine($"ardicil {sw.ElapsedMilliseconds}");
        }
        public static string[] GetUrls()
        {
            return new string[]
            {
                "https://docs.microsoft.com",
                "https://docs.microsoft.com/aspnet/core",
                "https://docs.microsoft.com/azure",
                "https://docs.microsoft.com/azure/devops",
                "https://docs.microsoft.com/dotnet",
                "https://docs.microsoft.com/dynamics365",
                "https://docs.microsoft.com/education",
                "https://docs.microsoft.com/enterprise-mobility-security",
                "https://docs.microsoft.com/gaming",
                "https://docs.microsoft.com/graph",
                "https://docs.microsoft.com/microsoft-365",
                "https://docs.microsoft.com/office",
                "https://docs.microsoft.com/powershell"
            };
        }
        #endregion
    }


}
